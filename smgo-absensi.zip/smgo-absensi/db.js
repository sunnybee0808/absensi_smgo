// Database SQLite: users, shifts, settings
const Database = require("better-sqlite3");
const path = require("path");
const fs = require("fs");

const file = process.env.DB_PATH || path.join(__dirname, "data", "absensi.db");
fs.mkdirSync(path.dirname(file), { recursive: true });
const db = new Database(file);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  discord_id  TEXT NOT NULL UNIQUE,
  username    TEXT NOT NULL,
  avatar      TEXT,
  full_name   TEXT,
  role        TEXT,
  active      INTEGER NOT NULL DEFAULT 1,
  is_admin    INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL,
  last_login  TEXT
);
CREATE TABLE IF NOT EXISTS shifts (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role        TEXT NOT NULL,
  on_at       TEXT NOT NULL,          -- ISO UTC
  off_at      TEXT,                   -- ISO UTC, NULL = masih on duty
  source      TEXT NOT NULL DEFAULT 'tombol', -- 'tombol' | 'manual'
  edited_by   INTEGER REFERENCES users(id) ON DELETE SET NULL,
  updated_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_shifts_on ON shifts(on_at);
CREATE UNIQUE INDEX IF NOT EXISTS idx_one_open_shift ON shifts(user_id) WHERE off_at IS NULL;
CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
`);

const DEFAULT_SETTINGS = {
  rounding: "blok",
  roles: [
    { id: "driver_junior", label: "Driver Junior", amount: 4, every: 1, unit: "jam" },
    { id: "driver_reguler", label: "Driver Reguler", amount: 5, every: 1, unit: "jam" },
    { id: "driver_senior", label: "Driver Senior", amount: 7, every: 1, unit: "jam" },
    { id: "manager", label: "Manager", amount: 12, every: 1, unit: "jam" },
    { id: "ceo", label: "CEO", amount: 25, every: 1, unit: "jam" },
  ],
};

function getSettings() {
  const row = db.prepare("SELECT value FROM settings WHERE key = 'rates'").get();
  if (!row) return JSON.parse(JSON.stringify(DEFAULT_SETTINGS));
  try { return JSON.parse(row.value); } catch { return JSON.parse(JSON.stringify(DEFAULT_SETTINGS)); }
}
function saveSettings(s) {
  db.prepare("INSERT INTO settings(key, value) VALUES('rates', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value")
    .run(JSON.stringify(s));
}

module.exports = { db, getSettings, saveSettings, DEFAULT_SETTINGS };
