# Absensi SMGO

Aplikasi absensi On Duty / Off Duty untuk SMGO Taxi Service dengan login Discord.

- Login dengan akun Discord. Bisa dibatasi hanya untuk anggota server Discord SMGO.
- Saat login pertama, setiap orang wajib mengisi **Full Name** sendiri. Setelah disimpan, hanya admin yang bisa mengubahnya.
- Setiap orang hanya bisa menekan On Duty / Off Duty untuk dirinya sendiri. Jam dicatat oleh server, jadi tidak bisa diakali dengan mengubah jam di HP.
- Role Driver Junior, Driver Reguler, Driver Senior, Manager, dan CEO dengan tarif bebas diatur, misalnya $3 setiap 30 menit.
- Laporan per periode dan unduhan Excel (.xlsx) berisi sheet Rekap, Rincian, dan Info.
- Admin bisa mencatat atau mengoreksi jam secara manual, menentukan role, menjadikan orang lain admin, dan menonaktifkan akun.

## 1. Buat aplikasi Discord

1. Buka https://discord.com/developers/applications lalu klik **New Application**, beri nama "Absensi SMGO".
2. Buka menu **OAuth2**.
3. Salin **Client ID**. Klik **Reset Secret** lalu salin **Client Secret**.
4. Di bagian **Redirects**, tambahkan alamat berikut lalu klik Save:
   - Lokal: `http://localhost:3000/auth/discord/callback`
   - Online: `https://alamat-anda.com/auth/discord/callback`

Alamat redirect harus sama persis dengan `BASE_URL` + `/auth/discord/callback`.

## 2. Siapkan konfigurasi

```bash
cp .env.example .env
```

Isi `.env`:

| Variabel | Isi |
|---|---|
| `DISCORD_CLIENT_ID` / `DISCORD_CLIENT_SECRET` | Dari langkah 1 |
| `ADMIN_DISCORD_IDS` | User ID Discord Anda (Discord → Settings → Advanced → Developer Mode, lalu klik kanan nama Anda → Copy User ID). Pisahkan dengan koma jika lebih dari satu. |
| `DISCORD_GUILD_ID` | Opsional. Server ID Discord SMGO, agar hanya anggota server yang bisa login. |
| `SESSION_SECRET` | String acak: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"` |
| `BASE_URL` | Alamat aplikasi, misalnya `https://absensi.smgo.com` |
| `TZ_ZONE` | Zona waktu, bawaan `Asia/Jakarta` |

## 3. Jalankan

Perlu Node.js 20 atau lebih baru.

```bash
npm install
npm start
```

Buka http://localhost:3000. Login dengan akun Discord admin, isi Full Name, lalu buka tab **Tarif & Karyawan** untuk mengatur tarif.

## 4. Alur pemakaian

1. Bagikan link aplikasi ke karyawan.
2. Karyawan login dengan Discord dan mengisi Full Name.
3. Admin membuka **Tarif & Karyawan** dan memilih role untuk orang tersebut. Karyawan tanpa role belum bisa absen.
4. Karyawan menekan **On Duty** saat mulai dan **Off Duty** saat selesai.
5. Di **Laporan & Excel**, pilih periode lalu tekan **Unduh Excel**. Admin melihat semua karyawan, sedangkan karyawan hanya melihat datanya sendiri.

Catatan perhitungan: upah dihitung dari tarif yang berlaku saat laporan dibuat. Role yang dipakai adalah role orang itu saat shift dimulai.

## 5. Online (hosting)

Aplikasi menyimpan data di file SQLite, jadi pilih hosting dengan **disk permanen**:

- **VPS** (misalnya DigitalOcean, Contabo, atau IDCloudHost): jalankan dengan `pm2 start server.js --name absensi`, lalu pasang Nginx + HTTPS (Let's Encrypt) di depannya.
- **Railway / Render / Fly.io**: deploy dengan `Dockerfile` yang sudah disediakan, lalu tambahkan *volume/disk* yang di-mount ke `/data`.

Di server online:

- Isi `NODE_ENV=production`.
- Isi `BASE_URL` dengan alamat `https://`.
- Tambahkan redirect online di Discord Developer Portal.

Vercel dan Netlify **tidak cocok** karena tidak punya disk permanen untuk database.

**Backup:** salin file `data/absensi.db` (atau `/data/absensi.db` di Docker) secara berkala.

## Uji coba tanpa Discord (komputer sendiri saja)

Isi `DEV_LOGIN=1` dan `SESSION_SECRET` di `.env`, lalu jalankan `npm start`. Halaman login akan menampilkan form "Masuk uji". Login uji coba otomatis mati saat `NODE_ENV=production`.

Agar akun uji menjadi admin, masukkan ID ujinya (misalnya `dev1`) ke `ADMIN_DISCORD_IDS`.
