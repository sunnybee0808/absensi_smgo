(function () {
"use strict";
const $ = id => document.getElementById(id);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const pad = n => String(n).padStart(2, "0");
const HARI = ["Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab"];
const BULAN = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"];
const UNITS = { menit: 1, jam: 60 };
const S = { me: null, settings: null, board: [], recent: [], users: [], report: null, editing: null };

/* ---------- API ---------- */
async function api(path, opts = {}) {
  const res = await fetch(path, {
    method: opts.method || "GET",
    headers: { "Content-Type": "application/json", "X-Requested-With": "smgo" },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
    credentials: "same-origin",
  });
  let data = {};
  try { data = await res.json(); } catch {}
  if (res.status === 401) { showLogin(); throw new Error(data.error || "Silakan login."); }
  if (!res.ok) throw new Error(data.error || "Terjadi kesalahan.");
  return data;
}
let tT;
function toast(m) { const t = $("toast"); t.textContent = m; t.hidden = false; clearTimeout(tT); tT = setTimeout(() => t.hidden = true, 2800); }
async function act(promise, okMsg) {
  try { const r = await promise; if (okMsg) toast(okMsg); return r || true; }
  catch (e) { toast(e.message); return false; }
}

/* ---------- format ---------- */
const parseLocal = s => s ? new Date(s) : null;
function fmtDate(s) { const d = parseLocal(s); return HARI[d.getDay()] + ", " + d.getDate() + " " + BULAN[d.getMonth()] + " " + d.getFullYear(); }
const fmtTime = s => s ? s.slice(11, 16) : "—";
function fmtDur(m) { m = Math.max(0, Math.floor(m)); return Math.floor(m / 60) + "j " + pad(m % 60) + "m"; }
const money = v => "$" + (Math.round(v * 100) / 100).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const dateOnly = d => d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
const isAdmin = () => !!(S.me && S.me.isAdmin);
function roleOf(id) { return (S.settings?.roles || []).find(r => r.id === id) || null; }
const rateText = r => r ? `$${r.amount} / ${r.every} ${r.unit}` : "—";
function avatar(url, name) {
  if (url) return `<img class="avatar" src="${esc(url)}" alt="" width="32" height="32" loading="lazy">`;
  const ini = String(name || "?").split(" ").map(w => w[0]).slice(0, 2).join("").toUpperCase();
  return `<span class="avatar fallback">${esc(ini)}</span>`;
}

/* ---------- screens ---------- */
function show(id) { ["screen-login", "screen-name", "screen-app"].forEach(s => $(s).hidden = s !== id); }
function showLogin(devLogin) {
  show("screen-login");
  if (devLogin) $("devLogin").hidden = false;
  const err = new URLSearchParams(location.search).get("login_error");
  if (err) {
    const msg = {
      dibatalkan: "Login dibatalkan.",
      state: "Sesi login kedaluwarsa. Coba lagi.",
      token: "Discord menolak login. Coba lagi.",
      profil: "Profil Discord tidak bisa dibaca. Coba lagi.",
      bukan_anggota: "Akun Discord Anda bukan anggota server SMGO. Minta undangan dari admin.",
      nonaktif: "Akun Anda dinonaktifkan. Hubungi admin.",
      server: "Server sedang bermasalah. Coba lagi sebentar.",
    }[err] || "Login gagal. Coba lagi.";
    $("loginErr").textContent = msg; $("loginErr").hidden = false;
    history.replaceState(null, "", "/");
  }
}
document.querySelectorAll("[data-logout]").forEach(b => b.addEventListener("click", async () => {
  await api("/api/logout", { method: "POST" }).catch(() => {});
  location.href = "/";
}));

/* ---------- Full Name ---------- */
$("nameForm").addEventListener("submit", async e => {
  e.preventDefault();
  const err = $("nameErr"); err.hidden = true;
  const name = $("fullName").value.replace(/\s+/g, " ").trim();
  if (name.length < 3) { err.textContent = "Full Name minimal 3 karakter."; err.hidden = false; return; }
  try { await api("/api/me/name", { method: "POST", body: { fullName: name } }); boot(); }
  catch (ex) { err.textContent = ex.message; err.hidden = false; }
});

/* ---------- tabs ---------- */
document.querySelectorAll("nav.tabs button").forEach(b => b.addEventListener("click", () => showTab(b.dataset.tab)));
function showTab(t) {
  if (t === "atur" && !isAdmin()) t = "absen";
  document.querySelectorAll("nav.tabs button").forEach(b => b.setAttribute("aria-selected", String(b.dataset.tab === t)));
  ["absen", "laporan", "atur"].forEach(v => $("view-" + v).hidden = v !== t);
  try { localStorage.setItem("smgo-tab", t); } catch {}
  if (t === "laporan") runReport();
  if (t === "atur") loadUsers();
}

/* ---------- clock & timers ---------- */
function tick() {
  const d = new Date();
  $("clkTime").textContent = pad(d.getHours()) + ":" + pad(d.getMinutes()) + ":" + pad(d.getSeconds());
  $("clkDate").textContent = HARI[d.getDay()] + ", " + d.getDate() + " " + BULAN[d.getMonth()] + " " + d.getFullYear();
  document.querySelectorAll("[data-since]").forEach(el => {
    const sec = Math.max(0, Math.floor((Date.now() - new Date(el.dataset.since)) / 1000));
    el.textContent = el.dataset.long ? `${pad(Math.floor(sec / 3600))}:${pad(Math.floor(sec / 60) % 60)}:${pad(sec % 60)}` : fmtDur(sec / 60);
  });
}

/* ---------- board ---------- */
async function loadBoard() {
  try { const d = await api("/api/board"); S.board = d.people; renderMyCard(); renderBoard(); } catch {}
}
function renderMyCard() {
  const me = S.board.find(p => p.isMe);
  const role = roleOf(S.me.role);
  let html;
  if (!S.me.role || !role) {
    html = `<div class="mycard"><div class="state"><b>Menunggu role</b><span class="sub">Admin belum menentukan role Anda. Setelah ditentukan, tombol On Duty muncul di sini.</span></div></div>`;
  } else if (me && me.open) {
    html = `<div class="mycard is-on"><div class="state"><span class="pill on">On duty sejak ${fmtTime(me.open.on)}</span><span class="timer" data-since="${esc(me.open.onIso)}" data-long="1">00:00:00</span><span class="sub">${esc(role.label)} · ${esc(rateText(role))}</span></div><button class="btn off big" id="btnOff">Off Duty</button></div>`;
  } else {
    html = `<div class="mycard"><div class="state"><span class="pill off">Off duty</span><b>Siap mulai?</b><span class="sub">${esc(role.label)} · ${esc(rateText(role))}</span></div><button class="btn on big" id="btnOn">On Duty</button></div>`;
  }
  $("mycard").innerHTML = html; tick();
}
$("mycard").addEventListener("click", async e => {
  const on = e.target.closest("#btnOn"), off = e.target.closest("#btnOff");
  if (!on && !off) return;
  (on || off).disabled = true;
  const ok = await act(api(on ? "/api/duty/on" : "/api/duty/off", { method: "POST" }), on ? "Selamat bekerja. On duty tercatat." : "Off duty tercatat. Terima kasih.");
  if (!ok) (on || off).disabled = false;
  loadBoard(); loadRecent();
});
function renderBoard() {
  const q = $("search").value.trim().toLowerCase();
  const list = S.board.filter(p => p.role && (!q || p.fullName.toLowerCase().includes(q)))
    .sort((a, b) => (!!b.open - !!a.open) || a.fullName.localeCompare(b.fullName));
  if (!list.length) { $("board").innerHTML = `<div class="empty">${q ? "Tidak ada nama yang cocok." : "<b>Belum ada karyawan</b>Karyawan muncul setelah login dan diberi role oleh admin."}</div>`; return; }
  $("board").innerHTML = list.map(p => `<div class="duty">${avatar(p.avatar, p.fullName)}
    <div class="who"><span class="name">${esc(p.fullName)}${p.isMe ? ' <span class="sub">(Anda)</span>' : ""}</span>
      <span class="meta"><span class="chip">${esc(p.roleLabel || "—")}</span></span></div>
    ${p.open ? `<span class="meta"><span class="pill on">sejak ${fmtTime(p.open.on)}</span><span class="mono" data-since="${esc(p.open.onIso)}"></span></span>` : `<span class="pill off">Off duty</span>`}
  </div>`).join("");
  tick();
}
$("search").addEventListener("input", renderBoard);

/* ---------- recent ---------- */
const HEAD = `<tr><th>Tanggal</th><th>Full Name</th><th>Role</th><th class="num">On</th><th class="num">Off</th><th class="num">Durasi</th><th class="num">Upah</th>`;
function shiftRow(s, withAct) {
  const offTxt = s.off ? (s.off.slice(0, 10) !== s.on.slice(0, 10) ? s.off.slice(8, 10) + "/" + s.off.slice(5, 7) + " " : "") + fmtTime(s.off) : '<span class="pill on">aktif</span>';
  return `<tr><td>${fmtDate(s.on)}</td><td>${esc(s.fullName)}</td><td><span class="chip">${esc(s.roleLabel)}</span></td>
    <td class="num">${fmtTime(s.on)}</td><td class="num">${offTxt}</td>
    <td class="num">${s.minutes == null ? "—" : fmtDur(s.minutes)}</td><td class="num">${s.pay == null ? "—" : money(s.pay)}</td>
    ${withAct ? `<td class="act"><button class="btn ghost" data-edit="${s.id}">Edit</button><button class="btn ghost danger" data-del="${s.id}">Hapus</button></td>` : ""}</tr>`;
}
async function loadRecent() {
  try { const d = await api("/api/shifts/recent"); S.recent = d.shifts; renderRecent(); } catch {}
}
function renderRecent() {
  $("recentSub").textContent = isAdmin() ? "100 catatan terakhir semua karyawan." : "100 catatan terakhir Anda.";
  if (!S.recent.length) { $("recent").innerHTML = '<div class="empty"><b>Belum ada catatan</b>Catatan muncul setelah tombol On Duty ditekan.</div>'; return; }
  const a = isAdmin();
  $("recent").innerHTML = `<div class="tbl-wrap"><table><thead>${HEAD}${a ? "<th></th>" : ""}</tr></thead><tbody>${S.recent.map(s => shiftRow(s, a)).join("")}</tbody></table></div>`;
}
$("recent").addEventListener("click", async e => {
  const ed = e.target.closest("[data-edit]"), del = e.target.closest("[data-del]");
  if (ed) {
    const s = S.recent.find(x => String(x.id) === ed.dataset.edit); if (!s) return;
    S.editing = s; await fillUserSelect(); $("mUser").value = String(s.userId);
    $("mOn").value = s.on; $("mOff").value = s.off || "";
    $("manualTitle").textContent = "Edit Catatan"; $("mSubmit").textContent = "Simpan perubahan"; $("mCancel").hidden = false;
    $("manualForm").scrollIntoView({ behavior: "smooth", block: "center" });
  }
  if (del) {
    if (!del.classList.contains("armed")) { del.classList.add("armed"); del.textContent = "Yakin?"; setTimeout(() => { del.classList.remove("armed"); del.textContent = "Hapus"; }, 3000); return; }
    if (await act(api("/api/shifts/" + del.dataset.del, { method: "DELETE" }), "Catatan dihapus")) { loadRecent(); loadBoard(); }
  }
});

/* ---------- manual (admin) ---------- */
async function fillUserSelect() {
  if (!S.users.length) await loadUsers(true);
  const list = S.users.filter(u => u.fullName && u.active).sort((a, b) => a.fullName.localeCompare(b.fullName));
  const cur = $("mUser").value;
  $("mUser").innerHTML = list.length ? list.map(u => `<option value="${u.id}">${esc(u.fullName)}${u.role ? " — " + esc(roleOf(u.role)?.label || "") : " (belum ada role)"}</option>`).join("") : '<option value="">Belum ada karyawan</option>';
  if (cur) $("mUser").value = cur;
}
function resetManual() {
  S.editing = null; $("manualForm").reset(); $("mErr").hidden = true;
  $("manualTitle").textContent = "Catat Manual"; $("mSubmit").textContent = "Simpan catatan"; $("mCancel").hidden = true;
}
$("mCancel").addEventListener("click", resetManual);
$("manualForm").addEventListener("submit", async e => {
  e.preventDefault(); const err = $("mErr"); err.hidden = true;
  const body = { userId: Number($("mUser").value), on: $("mOn").value, off: $("mOff").value };
  if (body.off && body.off <= body.on) { err.textContent = "Jam Off Duty harus setelah jam On Duty."; err.hidden = false; return; }
  try {
    await api(S.editing ? "/api/shifts/" + S.editing.id : "/api/shifts", { method: S.editing ? "PUT" : "POST", body });
    toast(S.editing ? "Perubahan disimpan" : "Catatan disimpan"); resetManual(); loadRecent(); loadBoard();
  } catch (ex) { err.textContent = ex.message; err.hidden = false; }
});

/* ---------- settings (admin) ---------- */
function renderRates() {
  $("rates").innerHTML = S.settings.roles.map(r => `<div class="rate-row">
    <span class="lbl">${esc(r.label)}</span>
    <label class="money"><input id="amt-${r.id}" type="number" min="0" step="0.01" value="${r.amount}" aria-label="Dollar untuk ${esc(r.label)}"></label>
    <span class="per">setiap</span>
    <input id="every-${r.id}" type="number" min="1" step="1" value="${r.every}" aria-label="Jumlah waktu ${esc(r.label)}">
    <select id="unit-${r.id}" aria-label="Satuan waktu ${esc(r.label)}"><option value="menit" ${r.unit === "menit" ? "selected" : ""}>menit</option><option value="jam" ${r.unit === "jam" ? "selected" : ""}>jam</option></select>
  </div>`).join("");
  $("rounding").value = S.settings.rounding; renderRoundEx();
}
function readRates() {
  return { rounding: $("rounding").value, roles: S.settings.roles.map(r => ({ id: r.id, amount: Number($("amt-" + r.id).value) || 0, every: Number($("every-" + r.id).value) || 1, unit: $("unit-" + r.id).value })) };
}
function renderRoundEx() {
  const r = readRates().roles[0]; const lbl = S.settings.roles[0].label;
  const block = Math.max(1, r.every) * UNITS[r.unit]; const m = 135;
  $("roundEx").textContent = `Contoh ${lbl}, kerja 2j 15m: blok penuh = ${money(Math.floor(m / block) * r.amount)}, proporsional = ${money(m / block * r.amount)}.`;
}
$("rates").addEventListener("input", renderRoundEx); $("rounding").addEventListener("change", renderRoundEx);
$("saveRates").addEventListener("click", async () => {
  const s = await act(api("/api/settings", { method: "PUT", body: readRates() }), "Tarif disimpan");
  if (s && s.roles) { S.settings = s; renderRates(); renderMyCard(); loadRecent(); }
});

async function loadUsers(silent) {
  if (!isAdmin()) return;
  try { const d = await api("/api/users"); S.users = d.users; if (!silent) renderUsers(); } catch (e) { if (!silent) toast(e.message); }
}
function renderUsers() {
  if (!S.users.length) { $("users").innerHTML = '<div class="empty"><b>Belum ada karyawan</b>Bagikan link aplikasi ini ke karyawan. Mereka muncul di sini setelah login dengan Discord.</div>'; return; }
  const roleOpts = sel => `<option value="">— Pilih role —</option>` + S.settings.roles.map(r => `<option value="${r.id}" ${r.id === sel ? "selected" : ""}>${esc(r.label)}</option>`).join("");
  $("users").innerHTML = `<div class="tbl-wrap"><table><thead><tr><th>Karyawan</th><th>Role</th><th>Akses</th><th></th></tr></thead><tbody>${
    S.users.map(u => `<tr data-uid="${u.id}" style="${u.active ? "" : "opacity:.55"}">
      <td><div class="person">${avatar(u.avatar, u.fullName || u.username)}<div>
        ${u.fullName ? esc(u.fullName) : '<span class="chip warn">Belum isi Full Name</span>'}
        ${u.isAdmin ? ' <span class="chip admin">Admin</span>' : ""}
        <small>Discord: ${esc(u.username)}</small></div></div></td>
      <td><select data-f="role" aria-label="Role">${roleOpts(u.role)}</select>${!u.role && u.fullName ? '<br><span class="chip warn">Perlu role</span>' : ""}</td>
      <td><label class="switch"><input type="checkbox" data-f="isAdmin" ${u.isAdmin ? "checked" : ""} ${u.envAdmin || u.id === S.me.id ? "disabled" : ""}> Admin</label><br>
          <label class="switch"><input type="checkbox" data-f="active" ${u.active ? "checked" : ""} ${u.id === S.me.id ? "disabled" : ""}> Aktif</label></td>
      <td class="act">${u.fullName ? `<button class="btn ghost" data-rename>Ubah nama</button>` : ""}</td>
    </tr>`).join("")}</tbody></table></div>`;
}
$("users").addEventListener("change", async e => {
  const el = e.target.closest("[data-f]"); if (!el) return;
  const tr = el.closest("[data-uid]"); const id = tr.dataset.uid; const f = el.dataset.f;
  const val = el.type === "checkbox" ? el.checked : el.value;
  const ok = await act(api("/api/users/" + id, { method: "PUT", body: { [f]: val } }), "Disimpan");
  await loadUsers(); if (ok) { loadBoard(); if (String(S.me.id) === id) boot(); }
});
$("users").addEventListener("click", e => {
  const b = e.target.closest("[data-rename]"); if (!b) return;
  const tr = b.closest("[data-uid]"); const u = S.users.find(x => String(x.id) === tr.dataset.uid);
  const cell = tr.querySelector("td .person div");
  cell.innerHTML = `<form class="row" data-renameform><input value="${esc(u.fullName)}" maxlength="60" aria-label="Full Name baru" style="min-width:160px"><button class="btn brand" type="submit">Simpan</button><button class="btn ghost" type="button" data-cancel>Batal</button></form>`;
  cell.querySelector("input").focus();
});
$("users").addEventListener("submit", async e => {
  const f = e.target.closest("[data-renameform]"); if (!f) return; e.preventDefault();
  const id = f.closest("[data-uid]").dataset.uid;
  if (await act(api("/api/users/" + id, { method: "PUT", body: { fullName: f.querySelector("input").value } }), "Nama diubah")) { loadBoard(); loadRecent(); }
  loadUsers();
});
$("users").addEventListener("click", e => { if (e.target.closest("[data-cancel]")) renderUsers(); });

/* ---------- report ---------- */
function setPeriod(p) {
  document.querySelectorAll("#periodSeg button").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.p === p)));
  const now = new Date(); let a, b;
  if (p === "today") a = b = now;
  else if (p === "week") { const dow = (now.getDay() + 6) % 7; a = new Date(now); a.setDate(now.getDate() - dow); b = new Date(a); b.setDate(a.getDate() + 6); }
  else if (p === "month") { a = new Date(now.getFullYear(), now.getMonth(), 1); b = new Date(now.getFullYear(), now.getMonth() + 1, 0); }
  else if (p === "lastmonth") { a = new Date(now.getFullYear(), now.getMonth() - 1, 1); b = new Date(now.getFullYear(), now.getMonth(), 0); }
  if (a) { $("rFrom").value = dateOnly(a); $("rTo").value = dateOnly(b); }
  if (p !== "custom") runReport(); else $("rFrom").focus();
}
document.querySelectorAll("#periodSeg button").forEach(b => b.addEventListener("click", () => setPeriod(b.dataset.p)));
["rFrom", "rTo"].forEach(id => $(id).addEventListener("change", () => {
  document.querySelectorAll("#periodSeg button").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.p === "custom"))); runReport();
}));
$("rUser").addEventListener("change", runReport);
function reportQuery() {
  const q = new URLSearchParams({ from: $("rFrom").value, to: $("rTo").value });
  if (isAdmin() && $("rUser").value) q.set("userId", $("rUser").value);
  return q.toString();
}
let seq = 0;
async function runReport() {
  const from = $("rFrom").value, to = $("rTo").value; if (!from || !to || !S.me) return;
  if (to < from) { $("rDetail").innerHTML = '<div class="empty">Tanggal akhir harus sama atau setelah tanggal awal.</div>'; return; }
  if (isAdmin()) {
    await loadUsers(true);
    const cur = $("rUser").value;
    $("rUser").innerHTML = '<option value="">Semua karyawan</option>' + S.users.filter(u => u.fullName).sort((a, b) => a.fullName.localeCompare(b.fullName)).map(u => `<option value="${u.id}">${esc(u.fullName)}</option>`).join("");
    $("rUser").value = cur;
  }
  const my = ++seq;
  try { const d = await api("/api/shifts?" + reportQuery()); if (my !== seq) return; S.report = d; renderReport(); }
  catch (e) { $("rDetail").innerHTML = `<div class="empty">${esc(e.message)}</div>`; }
}
function renderReport() {
  const { shifts, summary } = S.report;
  const tMin = summary.reduce((a, g) => a + g.minutes, 0), tPay = summary.reduce((a, g) => a + g.pay, 0), open = shifts.filter(s => s.minutes == null).length;
  $("rStats").innerHTML = `<div class="stat"><span>Shift</span><b>${shifts.length}</b></div><div class="stat"><span>Total jam kerja</span><b>${fmtDur(tMin)}</b></div><div class="stat hl"><span>Total upah</span><b>${money(tPay)}</b></div><div class="stat"><span>Masih aktif</span><b>${open}</b></div>`;
  const ex = $("btnExport");
  if (!shifts.length) {
    ex.setAttribute("aria-disabled", "true"); ex.style.opacity = ".45"; ex.style.pointerEvents = "none"; ex.href = "#";
    $("rSummary").innerHTML = '<div class="empty">Tidak ada catatan pada periode ini.</div>'; $("rDetail").innerHTML = ""; return;
  }
  ex.removeAttribute("aria-disabled"); ex.style.opacity = ""; ex.style.pointerEvents = ""; ex.href = "/api/export?" + reportQuery();
  $("rSummary").innerHTML = `<div class="tbl-wrap"><table><thead><tr><th>Full Name</th><th>Role</th><th>Tarif</th><th class="num">Shift</th><th class="num">Total jam</th><th class="num">Total upah</th></tr></thead><tbody>${
    summary.map(g => `<tr><td>${esc(g.fullName)}</td><td><span class="chip">${esc(g.roleLabel)}</span></td><td class="mono" style="color:var(--ink-3)">${esc(g.rate)}</td><td class="num">${g.shifts}${g.open ? ` <span class="pill on">${g.open} aktif</span>` : ""}</td><td class="num">${fmtDur(g.minutes)}</td><td class="num">${money(g.pay)}</td></tr>`).join("")
  }</tbody><tfoot><tr><td colspan="3">Total</td><td class="num">${shifts.length}</td><td class="num">${fmtDur(tMin)}</td><td class="num">${money(tPay)}</td></tr></tfoot></table></div>
  ${open ? '<p class="note">Shift yang masih aktif belum dihitung upahnya sampai Off Duty.</p>' : ""}`;
  $("rDetail").innerHTML = `<div class="tbl-wrap"><table><thead>${HEAD}</tr></thead><tbody>${shifts.map(s => shiftRow(s, false)).join("")}</tbody></table></div>`;
}

/* ---------- boot ---------- */
let polling = null;
async function boot() {
  let d;
  try { d = await (await fetch("/api/me", { credentials: "same-origin" })).json(); }
  catch { show("screen-login"); $("loginErr").textContent = "Tidak bisa terhubung ke server."; $("loginErr").hidden = false; return; }
  if (!d.user) return showLogin(d.devLogin);
  S.me = d.user; S.settings = d.settings;
  if (!S.me.fullName) { $("nameDiscord").textContent = S.me.username; show("screen-name"); $("fullName").focus(); return; }

  show("screen-app");
  $("tzNote").textContent = "Zona waktu " + d.tz;
  $("meAvatar").innerHTML = avatar(S.me.avatar, S.me.fullName);
  $("meName").textContent = S.me.fullName;
  $("meSub").textContent = (roleOf(S.me.role)?.label || "Belum ada role") + (S.me.isAdmin ? " · Admin" : "");
  document.querySelectorAll("[data-admin]").forEach(el => el.hidden = !S.me.isAdmin);
  if (S.me.isAdmin) { renderRates(); await loadUsers(true); fillUserSelect(); }

  await Promise.all([loadBoard(), loadRecent()]);
  let t = "absen"; try { t = localStorage.getItem("smgo-tab") || "absen"; } catch {}
  setPeriod("month"); showTab(["absen", "laporan", "atur"].includes(t) ? t : "absen");
  if (!polling) {
    setInterval(tick, 1000);
    polling = setInterval(() => { if (document.visibilityState === "visible" && !$("view-absen").hidden) { loadBoard(); loadRecent(); } }, 20000);
  }
}
boot();
})();
