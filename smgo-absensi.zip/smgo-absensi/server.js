// Absensi SMGO — server Express dengan login Discord
require("dotenv").config();
const express = require("express");
const cookieSession = require("cookie-session");
const crypto = require("crypto");
const path = require("path");
const ExcelJS = require("exceljs");
const { DateTime } = require("luxon");
const { db, getSettings, saveSettings } = require("./db");

const {
  PORT = 3000,
  BASE_URL = `http://localhost:${PORT}`,
  DISCORD_CLIENT_ID,
  DISCORD_CLIENT_SECRET,
  DISCORD_GUILD_ID = "",
  ADMIN_DISCORD_IDS = "",
  SESSION_SECRET,
  TZ_ZONE = "Asia/Jakarta",
  NODE_ENV = "development",
  DEV_LOGIN = "0",
} = process.env;

const PROD = NODE_ENV === "production";
if (!SESSION_SECRET || SESSION_SECRET.length < 16) {
  console.error("SESSION_SECRET wajib diisi (minimal 16 karakter) di file .env");
  process.exit(1);
}
const devLoginEnabled = !PROD && DEV_LOGIN === "1";
if (!devLoginEnabled && (!DISCORD_CLIENT_ID || !DISCORD_CLIENT_SECRET)) {
  console.error("DISCORD_CLIENT_ID dan DISCORD_CLIENT_SECRET wajib diisi di file .env");
  process.exit(1);
}
const ENV_ADMINS = new Set(ADMIN_DISCORD_IDS.split(",").map(s => s.trim()).filter(Boolean));
const REDIRECT_URI = `${BASE_URL.replace(/\/$/, "")}/auth/discord/callback`;

const app = express();
app.set("trust proxy", 1);
app.disable("x-powered-by");
app.use(express.json({ limit: "100kb" }));
app.use(cookieSession({
  name: "smgo_sess",
  keys: [SESSION_SECRET],
  maxAge: 30 * 24 * 60 * 60 * 1000,
  sameSite: "lax",
  httpOnly: true,
  secure: PROD,
}));
app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "same-origin");
  res.setHeader("X-Frame-Options", "DENY");
  next();
});

/* ---------------- helpers ---------------- */
const nowIso = () => new Date().toISOString();
const UNITS = { menit: 1, jam: 60 };
function roleOf(settings, id) {
  return settings.roles.find(r => r.id === id) || null;
}
function rateText(r) { return r ? `$${r.amount} / ${r.every} ${r.unit}` : "-"; }
function minutesBetween(a, b) {
  return Math.max(0, Math.round((new Date(b) - new Date(a)) / 60000));
}
function calcPay(settings, minutes, roleId) {
  const r = roleOf(settings, roleId);
  if (!r) return 0;
  const block = (Number(r.every) || 1) * (UNITS[r.unit] || 60);
  const n = settings.rounding === "proporsional" ? minutes / block : Math.floor(minutes / block);
  return Math.round(n * (Number(r.amount) || 0) * 100) / 100;
}
const toLocal = iso => iso ? DateTime.fromISO(iso, { zone: "utc" }).setZone(TZ_ZONE).toFormat("yyyy-LL-dd'T'HH:mm") : "";
function fromLocal(s) {
  if (!s || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(s)) return null;
  const dt = DateTime.fromISO(s, { zone: TZ_ZONE });
  return dt.isValid ? dt.toUTC().toISO() : null;
}
function dayRange(from, to) {
  const re = /^\d{4}-\d{2}-\d{2}$/;
  if (!re.test(from) || !re.test(to)) return null;
  const a = DateTime.fromISO(from, { zone: TZ_ZONE }).startOf("day");
  const b = DateTime.fromISO(to, { zone: TZ_ZONE }).endOf("day");
  if (!a.isValid || !b.isValid || b < a) return null;
  return [a.toUTC().toISO(), b.toUTC().toISO()];
}
function isAdmin(u) { return !!u && (ENV_ADMINS.has(u.discord_id) || u.is_admin === 1); }
function publicUser(u) {
  return {
    id: u.id, discordId: u.discord_id, username: u.username, avatar: u.avatar,
    fullName: u.full_name, role: u.role, active: !!u.active,
    isAdmin: isAdmin(u), envAdmin: ENV_ADMINS.has(u.discord_id),
  };
}
function cleanName(s) {
  const n = String(s || "").replace(/\s+/g, " ").trim();
  if (n.length < 3 || n.length > 60) return null;
  if (!/^[\p{L}][\p{L}\p{M} .'\-]*$/u.test(n)) return null;
  return n;
}
function enrich(rows, settings) {
  return rows.map(s => {
    const minutes = s.off_at ? minutesBetween(s.on_at, s.off_at) : null;
    const r = roleOf(settings, s.role);
    return {
      id: s.id, userId: s.user_id, fullName: s.full_name || s.username, username: s.username,
      role: s.role, roleLabel: r ? r.label : s.role, rate: rateText(r),
      on: toLocal(s.on_at), off: toLocal(s.off_at),
      minutes, pay: minutes == null ? null : calcPay(settings, minutes, s.role),
      source: s.source,
    };
  });
}
const SHIFT_SELECT = `SELECT s.*, u.full_name, u.username FROM shifts s JOIN users u ON u.id = s.user_id`;

/* ---------------- auth middleware ---------------- */
function loadUser(req) {
  if (!req.session || !req.session.uid) return null;
  const u = db.prepare("SELECT * FROM users WHERE id = ?").get(req.session.uid);
  if (!u || !u.active) { req.session = null; return null; }
  return u;
}
function requireUser(req, res, next) {
  const u = loadUser(req);
  if (!u) return res.status(401).json({ error: "Silakan login dengan Discord." });
  req.user = u; next();
}
function requireName(req, res, next) {
  if (!req.user.full_name) return res.status(403).json({ error: "Isi Full Name terlebih dahulu." });
  next();
}
function requireAdmin(req, res, next) {
  if (!isAdmin(req.user)) return res.status(403).json({ error: "Hanya admin yang dapat melakukan ini." });
  next();
}
// Perlindungan CSRF sederhana untuk request yang mengubah data
app.use("/api", (req, res, next) => {
  if (req.method !== "GET" && req.get("X-Requested-With") !== "smgo") {
    return res.status(403).json({ error: "Permintaan ditolak." });
  }
  next();
});

/* ---------------- Discord OAuth ---------------- */
app.get("/auth/discord", (req, res) => {
  const state = crypto.randomBytes(16).toString("hex");
  req.session.oauthState = state;
  const scope = DISCORD_GUILD_ID ? "identify guilds" : "identify";
  const q = new URLSearchParams({
    client_id: DISCORD_CLIENT_ID, redirect_uri: REDIRECT_URI, response_type: "code",
    scope, state, prompt: "none",
  });
  res.redirect(`https://discord.com/oauth2/authorize?${q}`);
});

app.get("/auth/discord/callback", async (req, res) => {
  const fail = code => res.redirect(`/?login_error=${code}`);
  try {
    const { code, state, error } = req.query;
    if (error) return fail("dibatalkan");
    if (!code || !state || state !== req.session.oauthState) return fail("state");
    req.session.oauthState = null;

    const tokenRes = await fetch("https://discord.com/api/oauth2/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: DISCORD_CLIENT_ID, client_secret: DISCORD_CLIENT_SECRET,
        grant_type: "authorization_code", code, redirect_uri: REDIRECT_URI,
      }),
    });
    if (!tokenRes.ok) return fail("token");
    const token = await tokenRes.json();
    const auth = { Authorization: `Bearer ${token.access_token}` };

    const meRes = await fetch("https://discord.com/api/users/@me", { headers: auth });
    if (!meRes.ok) return fail("profil");
    const me = await meRes.json();

    if (DISCORD_GUILD_ID) {
      const gRes = await fetch("https://discord.com/api/users/@me/guilds", { headers: auth });
      const guilds = gRes.ok ? await gRes.json() : [];
      if (!Array.isArray(guilds) || !guilds.some(g => g.id === DISCORD_GUILD_ID)) return fail("bukan_anggota");
    }

    const uid = upsertDiscordUser({
      id: me.id,
      username: me.global_name || me.username,
      avatar: me.avatar ? `https://cdn.discordapp.com/avatars/${me.id}/${me.avatar}.png?size=64` : null,
    });
    if (!uid) return fail("nonaktif");
    req.session.uid = uid;
    res.redirect("/");
  } catch (e) {
    console.error("OAuth error:", e);
    fail("server");
  }
});

function upsertDiscordUser({ id, username, avatar }) {
  const existing = db.prepare("SELECT * FROM users WHERE discord_id = ?").get(id);
  if (existing) {
    if (!existing.active) return null;
    db.prepare("UPDATE users SET username = ?, avatar = ?, last_login = ? WHERE id = ?")
      .run(username, avatar, nowIso(), existing.id);
    return existing.id;
  }
  const r = db.prepare("INSERT INTO users(discord_id, username, avatar, created_at, last_login) VALUES(?,?,?,?,?)")
    .run(id, username, avatar, nowIso(), nowIso());
  return r.lastInsertRowid;
}

// Login uji coba lokal tanpa Discord (hanya jika DEV_LOGIN=1 dan bukan production)
if (devLoginEnabled) {
  console.warn("⚠  DEV_LOGIN aktif: /auth/dev?id=123&name=Tes bisa login tanpa Discord. Jangan dipakai di server publik.");
  app.get("/auth/dev", (req, res) => {
    const id = String(req.query.id || "dev1").replace(/[^\w]/g, "").slice(0, 30) || "dev1";
    const uid = upsertDiscordUser({ id, username: String(req.query.name || id).slice(0, 40), avatar: null });
    if (!uid) return res.redirect("/?login_error=nonaktif");
    req.session.uid = uid; res.redirect("/");
  });
}

app.post("/api/logout", (req, res) => { req.session = null; res.json({ ok: true }); });

/* ---------------- API: akun ---------------- */
app.get("/api/me", (req, res) => {
  const u = loadUser(req);
  if (!u) return res.json({ user: null, devLogin: devLoginEnabled });
  res.json({ user: publicUser(u), settings: getSettings(), tz: TZ_ZONE, now: toLocal(nowIso()) });
});

app.post("/api/me/name", requireUser, (req, res) => {
  if (req.user.full_name && !isAdmin(req.user)) {
    return res.status(403).json({ error: "Full Name sudah diisi. Minta admin untuk mengubahnya." });
  }
  const name = cleanName(req.body.fullName);
  if (!name) return res.status(400).json({ error: "Full Name 3–60 karakter, hanya huruf, spasi, titik, apostrof, atau tanda hubung." });
  db.prepare("UPDATE users SET full_name = ? WHERE id = ?").run(name, req.user.id);
  res.json({ ok: true, fullName: name });
});

/* ---------------- API: papan tugas ---------------- */
app.get("/api/board", requireUser, requireName, (req, res) => {
  const settings = getSettings();
  const users = db.prepare("SELECT * FROM users WHERE active = 1 AND full_name IS NOT NULL ORDER BY full_name COLLATE NOCASE").all();
  const open = db.prepare("SELECT * FROM shifts WHERE off_at IS NULL").all();
  const byUser = new Map(open.map(s => [s.user_id, s]));
  res.json({
    now: toLocal(nowIso()),
    people: users.map(u => {
      const s = byUser.get(u.id); const r = roleOf(settings, u.role);
      return {
        id: u.id, fullName: u.full_name, avatar: u.avatar, role: u.role, roleLabel: r ? r.label : null,
        open: s ? { id: s.id, on: toLocal(s.on_at), onIso: s.on_at } : null,
        isMe: u.id === req.user.id,
      };
    }),
  });
});

app.post("/api/duty/on", requireUser, requireName, (req, res) => {
  const u = req.user;
  if (!u.role || !roleOf(getSettings(), u.role)) return res.status(400).json({ error: "Role Anda belum ditentukan admin. Hubungi admin." });
  try {
    db.prepare("INSERT INTO shifts(user_id, role, on_at, source, updated_at) VALUES(?,?,?,?,?)")
      .run(u.id, u.role, nowIso(), "tombol", nowIso());
  } catch (e) {
    if (String(e.message).includes("UNIQUE")) return res.status(409).json({ error: "Anda sudah on duty." });
    throw e;
  }
  res.json({ ok: true });
});

app.post("/api/duty/off", requireUser, requireName, (req, res) => {
  const r = db.prepare("UPDATE shifts SET off_at = ?, updated_at = ? WHERE user_id = ? AND off_at IS NULL")
    .run(nowIso(), nowIso(), req.user.id);
  if (!r.changes) return res.status(409).json({ error: "Anda sedang tidak on duty." });
  res.json({ ok: true });
});

/* ---------------- API: catatan shift ---------------- */
app.get("/api/shifts/recent", requireUser, requireName, (req, res) => {
  const settings = getSettings();
  const admin = isAdmin(req.user);
  const rows = admin
    ? db.prepare(`${SHIFT_SELECT} ORDER BY s.on_at DESC LIMIT 100`).all()
    : db.prepare(`${SHIFT_SELECT} WHERE s.user_id = ? ORDER BY s.on_at DESC LIMIT 100`).all(req.user.id);
  res.json({ shifts: enrich(rows, settings) });
});

function rangeRows(req) {
  const range = dayRange(String(req.query.from || ""), String(req.query.to || ""));
  if (!range) return null;
  let userId = req.query.userId ? Number(req.query.userId) : null;
  if (!isAdmin(req.user)) userId = req.user.id;
  const rows = userId
    ? db.prepare(`${SHIFT_SELECT} WHERE s.on_at BETWEEN ? AND ? AND s.user_id = ? ORDER BY s.on_at`).all(range[0], range[1], userId)
    : db.prepare(`${SHIFT_SELECT} WHERE s.on_at BETWEEN ? AND ? ORDER BY s.on_at`).all(range[0], range[1]);
  return rows;
}
function summarize(shifts) {
  const by = new Map();
  for (const s of shifts) {
    if (!by.has(s.userId)) by.set(s.userId, { userId: s.userId, fullName: s.fullName, role: s.role, roleLabel: s.roleLabel, rate: s.rate, shifts: 0, minutes: 0, pay: 0, open: 0 });
    const g = by.get(s.userId); g.shifts++;
    if (s.minutes == null) g.open++; else { g.minutes += s.minutes; g.pay = Math.round((g.pay + s.pay) * 100) / 100; }
    g.role = s.role; g.roleLabel = s.roleLabel; g.rate = s.rate;
  }
  return [...by.values()].sort((a, b) => a.fullName.localeCompare(b.fullName));
}

app.get("/api/shifts", requireUser, requireName, (req, res) => {
  const rows = rangeRows(req);
  if (!rows) return res.status(400).json({ error: "Periode tidak valid." });
  const shifts = enrich(rows, getSettings());
  res.json({ shifts, summary: summarize(shifts) });
});

function readShiftBody(body, existing) {
  const userId = Number(body.userId);
  const u = db.prepare("SELECT * FROM users WHERE id = ?").get(userId);
  if (!u || !u.full_name) return { error: "Karyawan tidak ditemukan." };
  const on = fromLocal(body.on);
  if (!on) return { error: "Isi jam On Duty dengan benar." };
  const off = body.off ? fromLocal(body.off) : null;
  if (body.off && !off) return { error: "Format jam Off Duty tidak valid." };
  if (off && off <= on) return { error: "Jam Off Duty harus setelah jam On Duty." };
  const role = existing && existing.user_id === userId ? existing.role : u.role;
  if (!role) return { error: `${u.full_name} belum punya role. Atur dulu di Tarif & Karyawan.` };
  return { userId, on, off, role };
}

app.post("/api/shifts", requireUser, requireAdmin, (req, res) => {
  const v = readShiftBody(req.body);
  if (v.error) return res.status(400).json({ error: v.error });
  try {
    db.prepare("INSERT INTO shifts(user_id, role, on_at, off_at, source, edited_by, updated_at) VALUES(?,?,?,?,?,?,?)")
      .run(v.userId, v.role, v.on, v.off, "manual", req.user.id, nowIso());
  } catch (e) {
    if (String(e.message).includes("UNIQUE")) return res.status(409).json({ error: "Karyawan ini masih on duty. Isi jam Off Duty." });
    throw e;
  }
  res.json({ ok: true });
});

app.put("/api/shifts/:id", requireUser, requireAdmin, (req, res) => {
  const existing = db.prepare("SELECT * FROM shifts WHERE id = ?").get(Number(req.params.id));
  if (!existing) return res.status(404).json({ error: "Catatan tidak ditemukan." });
  const v = readShiftBody(req.body, existing);
  if (v.error) return res.status(400).json({ error: v.error });
  try {
    db.prepare("UPDATE shifts SET user_id = ?, role = ?, on_at = ?, off_at = ?, source = 'manual', edited_by = ?, updated_at = ? WHERE id = ?")
      .run(v.userId, v.role, v.on, v.off, req.user.id, nowIso(), existing.id);
  } catch (e) {
    if (String(e.message).includes("UNIQUE")) return res.status(409).json({ error: "Karyawan ini sudah punya shift aktif." });
    throw e;
  }
  res.json({ ok: true });
});

app.delete("/api/shifts/:id", requireUser, requireAdmin, (req, res) => {
  db.prepare("DELETE FROM shifts WHERE id = ?").run(Number(req.params.id));
  res.json({ ok: true });
});

/* ---------------- API: tarif & karyawan (admin) ---------------- */
app.get("/api/settings", requireUser, (req, res) => res.json(getSettings()));

app.put("/api/settings", requireUser, requireAdmin, (req, res) => {
  const cur = getSettings();
  const body = req.body || {};
  const roles = cur.roles.map(r => {
    const n = (body.roles || []).find(x => x && x.id === r.id) || r;
    return {
      id: r.id, label: r.label,
      amount: Math.max(0, Math.round((Number(n.amount) || 0) * 100) / 100),
      every: Math.max(1, Math.min(10000, Math.round(Number(n.every) || 1))),
      unit: n.unit === "menit" ? "menit" : "jam",
    };
  });
  const s = { rounding: body.rounding === "proporsional" ? "proporsional" : "blok", roles };
  saveSettings(s);
  res.json(s);
});

app.get("/api/users", requireUser, requireAdmin, (req, res) => {
  const rows = db.prepare("SELECT * FROM users ORDER BY active DESC, full_name IS NULL, full_name COLLATE NOCASE").all();
  res.json({ users: rows.map(publicUser) });
});

app.put("/api/users/:id", requireUser, requireAdmin, (req, res) => {
  const u = db.prepare("SELECT * FROM users WHERE id = ?").get(Number(req.params.id));
  if (!u) return res.status(404).json({ error: "Karyawan tidak ditemukan." });
  const b = req.body || {};
  const settings = getSettings();
  let { full_name, role, active, is_admin } = u;
  if ("fullName" in b) { const n = cleanName(b.fullName); if (!n) return res.status(400).json({ error: "Full Name tidak valid." }); full_name = n; }
  if ("role" in b) { if (b.role && !roleOf(settings, b.role)) return res.status(400).json({ error: "Role tidak dikenal." }); role = b.role || null; }
  if ("active" in b) {
    if (u.id === req.user.id && !b.active) return res.status(400).json({ error: "Anda tidak bisa menonaktifkan akun sendiri." });
    active = b.active ? 1 : 0;
  }
  if ("isAdmin" in b) {
    if (u.id === req.user.id && !b.isAdmin) return res.status(400).json({ error: "Anda tidak bisa mencabut admin dari akun sendiri." });
    is_admin = b.isAdmin ? 1 : 0;
  }
  db.prepare("UPDATE users SET full_name = ?, role = ?, active = ?, is_admin = ? WHERE id = ?").run(full_name, role, active, is_admin, u.id);
  if (!active) db.prepare("UPDATE shifts SET off_at = ?, updated_at = ? WHERE user_id = ? AND off_at IS NULL").run(nowIso(), nowIso(), u.id);
  res.json({ ok: true });
});

/* ---------------- Ekspor Excel ---------------- */
app.get("/api/export", requireUser, requireName, async (req, res) => {
  const rows = rangeRows(req);
  if (!rows) return res.status(400).json({ error: "Periode tidak valid." });
  const settings = getSettings();
  const shifts = enrich(rows, settings);
  const sum = summarize(shifts);
  const from = String(req.query.from), to = String(req.query.to);

  const wb = new ExcelJS.Workbook();
  wb.creator = "Absensi SMGO";
  const head = { font: { bold: true, color: { argb: "FFFFFFFF" } }, fill: { type: "pattern", pattern: "solid", fgColor: { argb: "FF13836A" } } };
  const usd = '"$"#,##0.00';
  const styleHeader = ws => ws.getRow(1).eachCell(c => { c.font = head.font; c.fill = head.fill; });

  const r1 = wb.addWorksheet("Rekap");
  r1.columns = [
    { header: "Full Name", key: "n", width: 26 }, { header: "Role", key: "r", width: 16 },
    { header: "Tarif", key: "t", width: 18 }, { header: "Jumlah Shift", key: "s", width: 13 },
    { header: "Total Menit", key: "m", width: 12 }, { header: "Total Jam", key: "h", width: 11 },
    { header: "Total Upah (USD)", key: "p", width: 17, style: { numFmt: usd } },
  ];
  sum.forEach(g => r1.addRow({ n: g.fullName, r: g.roleLabel, t: g.rate, s: g.shifts, m: g.minutes, h: Math.round(g.minutes / 60 * 100) / 100, p: g.pay }));
  const tMin = sum.reduce((a, g) => a + g.minutes, 0), tPay = Math.round(sum.reduce((a, g) => a + g.pay, 0) * 100) / 100;
  const tr = r1.addRow({ n: "TOTAL", s: shifts.length, m: tMin, h: Math.round(tMin / 60 * 100) / 100, p: tPay });
  tr.font = { bold: true };
  styleHeader(r1); r1.views = [{ state: "frozen", ySplit: 1 }];

  const r2 = wb.addWorksheet("Rincian");
  r2.columns = [
    { header: "Tanggal", key: "d", width: 12 }, { header: "Full Name", key: "n", width: 26 },
    { header: "Role", key: "r", width: 16 }, { header: "Tarif", key: "t", width: 18 },
    { header: "Jam On Duty", key: "on", width: 18 }, { header: "Jam Off Duty", key: "off", width: 18 },
    { header: "Durasi (menit)", key: "m", width: 14 }, { header: "Durasi (jam)", key: "h", width: 12 },
    { header: "Upah (USD)", key: "p", width: 13, style: { numFmt: usd } }, { header: "Sumber", key: "src", width: 10 },
  ];
  shifts.forEach(s => r2.addRow({
    d: s.on.slice(0, 10), n: s.fullName, r: s.roleLabel, t: s.rate,
    on: s.on.replace("T", " "), off: s.off ? s.off.replace("T", " ") : "Masih aktif",
    m: s.minutes ?? "", h: s.minutes == null ? "" : Math.round(s.minutes / 60 * 100) / 100,
    p: s.pay ?? "", src: s.source,
  }));
  styleHeader(r2); r2.views = [{ state: "frozen", ySplit: 1 }];
  r2.autoFilter = { from: "A1", to: "J1" };

  const r3 = wb.addWorksheet("Info");
  r3.columns = [{ width: 18 }, { width: 34 }];
  [["Laporan Absensi SMGO"], ["Periode", `${from} s/d ${to}`], ["Zona waktu", TZ_ZONE],
   ["Cara hitung", settings.rounding === "proporsional" ? "Proporsional per menit" : "Blok waktu penuh"],
   ["Dibuat", toLocal(nowIso()).replace("T", " ")], ["Dibuat oleh", req.user.full_name], [], ["Role", "Tarif"],
   ...settings.roles.map(r => [r.label, rateText(r)])].forEach(row => r3.addRow(row));
  r3.getRow(1).font = { bold: true, size: 14 };

  const filename = `Absensi_SMGO_${from}_sd_${to}.xlsx`;
  res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
  res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
  await wb.xlsx.write(res);
  res.end();
});

/* ---------------- static & errors ---------------- */
app.use(express.static(path.join(__dirname, "public"), { index: "index.html", maxAge: PROD ? "1h" : 0 }));
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "Terjadi kesalahan di server." });
});

app.listen(PORT, () => console.log(`Absensi SMGO berjalan di ${BASE_URL} (zona waktu ${TZ_ZONE})`));
